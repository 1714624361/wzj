package com.dbsun.service;

import org.springframework.stereotype.Service;

@Service
public class LoginlogService {
//	@Autowired
//	 private LoginlogMapper logmapper;
//	public void addLog(Loginlog log){
//		logmapper.addLog(log);
//	}
	
}
